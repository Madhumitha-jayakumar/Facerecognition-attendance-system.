import { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Camera, Lock, User, CheckCircle2 } from 'lucide-react';
import useAuthStore from '../../store/authStore';

const Login = () => {
    const [userId, setUserId] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const login = useAuthStore((state) => state.login);

    const handleLogin = (e) => {
        e.preventDefault();
        setError('');

        if (!userId.trim()) {
            setError('Faculty ID is required');
            return;
        }

        if (password.length < 6) {
            setError('Password must be at least 6 characters');
            return;
        }

        setIsLoading(true);

        // Simple MCA project logic - any input works
        setTimeout(() => {
            login(userId);
            navigate('/');
            setIsLoading(false);
        }, 1500);
    };

    return (
        <div className="min-h-screen bg-[#020617] flex items-center justify-center p-4 relative overflow-hidden text-slate-100">
            {/* Background Orbs */}
            <div className="absolute top-[-200px] left-[-100px] w-96 h-96 bg-primary-600/10 rounded-full blur-[120px]"></div>
            <div className="absolute bottom-[-200px] right-[-100px] w-96 h-96 bg-blue-600/10 rounded-full blur-[120px]"></div>

            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full max-w-md glass-card rounded-[32px] p-10 z-10 border border-slate-800/50"
            >
                <div className="flex flex-col items-center mb-10">
                    <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-primary-600 to-blue-600 flex items-center justify-center mb-6 shadow-2xl shadow-primary-600/20">
                        <Camera size={40} className="text-white" />
                    </div>
                    <h1 className="text-3xl font-bold tracking-tight text-white text-center">MCA Department Portal</h1>
                    <p className="text-slate-500 mt-2 font-medium">Faculty Attendance Login</p>
                </div>

                {error && (
                    <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-2xl text-xs font-bold mb-8 text-center uppercase tracking-wider">
                        {error}
                    </div>
                )}

                <form onSubmit={handleLogin} className="space-y-6">
                    <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Faculty ID</label>
                        <div className="relative group">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-500 group-focus-within:text-primary-400 transition-colors">
                                <User size={18} />
                            </div>
                            <input
                                type="text"
                                value={userId}
                                onChange={(e) => setUserId(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 focus:border-primary-500 outline-none transition-all text-white placeholder-slate-600 text-sm"
                                placeholder="e.g. CS-FAC-01"
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Password</label>
                        <div className="relative group">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-500 group-focus-within:text-primary-400 transition-colors">
                                <Lock size={18} />
                            </div>
                            <input
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 focus:border-primary-500 outline-none transition-all text-white placeholder-slate-600 text-sm"
                                placeholder="••••••••"
                            />
                        </div>
                    </div>

                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full py-4 rounded-2xl bg-primary-600 hover:bg-primary-500 text-white font-bold shadow-xl shadow-primary-600/20 transition-all transform active:scale-[0.98] disabled:opacity-50"
                    >
                        {isLoading ? 'Authenticating...' : 'Login to System'}
                    </button>
                </form>

                <div className="mt-10 pt-8 border-t border-slate-800/50 text-center">
                    <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">
                        Computer Science Attendance System 2026
                    </p>
                </div>
            </motion.div>
        </div>
    );
};

export default Login;
