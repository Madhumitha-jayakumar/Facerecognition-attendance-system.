import { useState } from 'react';
import { motion } from 'framer-motion';
import {
    Users,
    Calendar,
    CheckCircle2,
    Clock,
    UserCheck,
    GraduationCap,
    Computer,
    BookOpen
} from 'lucide-react';
import useStudentStore from '../../store/studentStore';

const StatCard = ({ title, value, icon: Icon, color }) => (
    <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.4 }}
        className="glass-card p-6 rounded-[32px] relative overflow-hidden group border border-slate-800/50"
    >
        <div className={`absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 rounded-full bg-${color}-500/5 blur-2xl group-hover:bg-${color}-500/10 transition-colors`}></div>
        <div className="flex items-start justify-between relative z-10">
            <div>
                <p className="text-slate-500 text-[10px] uppercase font-bold tracking-widest mb-2">{title}</p>
                <h3 className="text-3xl font-black text-white">{value}</h3>
            </div>
            <div className={`p-4 rounded-2xl bg-${color}-500/10 text-${color}-400 shadow-inner`}>
                <Icon size={24} />
            </div>
        </div>
    </motion.div>
);

const DashboardOverview = () => {
    const { students } = useStudentStore();
    const csStudents = students.filter(s => s.dept.includes('Computer Science') || s.dept === 'MCA');

    const [isRefreshing, setIsRefreshing] = useState(false);

    const handleRefresh = () => {
        setIsRefreshing(true);
        setTimeout(() => setIsRefreshing(false), 2000);
    };

    const stats = [
        { title: 'CS Students', value: csStudents.length, icon: Computer, color: 'blue' },
        { title: 'Total Batch', value: 'MCA 2026', icon: GraduationCap, color: 'purple' },
        { title: 'Pass Criteria', value: '75%', icon: CheckCircle2, color: 'green' },
        { title: 'Today\'s Session', value: 'Active', icon: Clock, color: 'orange' },
    ];

    const recentLogs = [
        { id: 1, title: 'AI Module', msg: 'Face detection engine stable', status: 'Online', color: 'green' },
        { id: 2, title: 'MCA Batch', msg: 'Student roster updated', status: 'Success', color: 'blue' },
        { id: 3, title: 'Database', msg: 'Attendance storage synced', status: 'Ready', color: 'purple' },
    ];

    return (
        <div className="space-y-10">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                >
                    <h1 className="text-4xl font-black text-white tracking-tighter uppercase leading-none">
                        Meenakshi college for women chennai
                    </h1>
                    <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px] mt-4">
                        MCA Department • Attendance Portal
                    </p>
                </motion.div>

                <div className="flex items-center gap-3 bg-slate-900 px-6 py-3 rounded-2xl border border-slate-800">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                    <span className="text-xs font-bold text-slate-300">SERVER STATUS: {isRefreshing ? 'REFRESHING...' : 'ACTIVE'}</span>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {stats.map((stat, index) => (
                    <StatCard key={index} {...stat} />
                ))}
            </div>

            {/* System Status Sidebar Only */}
            <div className="flex flex-col lg:flex-row gap-8 pb-10">
                <div className="glass-card p-8 rounded-[40px] border border-slate-800/50 flex flex-col w-full">
                    <h3 className="text-xl font-bold text-white mb-8 tracking-tight">System Logs</h3>
                    <div className="space-y-8 flex-1">
                        {recentLogs.map((log) => (
                            <div key={log.id} className="flex gap-5 group">
                                <div className={`w-12 h-12 rounded-[18px] bg-${log.color}-500/10 flex items-center justify-center text-${log.color}-400 group-hover:scale-110 transition-transform`}>
                                    <BookOpen size={20} />
                                </div>
                                <div className="flex-1 border-b border-slate-800/30 pb-4">
                                    <div className="flex justify-between items-start mb-1">
                                        <h4 className="text-sm font-bold text-white uppercase tracking-tight">{log.title}</h4>
                                        <span className={`text-[8px] font-black px-2 py-0.5 rounded-full bg-${log.color}-500/10 text-${log.color}-500`}>{log.status}</span>
                                    </div>
                                    <p className="text-xs text-slate-500 font-medium leading-relaxed">{log.msg}</p>
                                </div>
                            </div>
                        ))}
                    </div>

                    <button
                        onClick={handleRefresh}
                        disabled={isRefreshing}
                        className="w-full mt-10 py-4 rounded-2xl bg-white text-slate-950 text-[10px] font-black uppercase tracking-widest hover:bg-slate-100 transition-all shadow-xl shadow-white/5 active:scale-95 disabled:opacity-50"
                    >
                        {isRefreshing ? 'Refreshing Diagnostics...' : 'Refresh Diagnostics'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default DashboardOverview;
