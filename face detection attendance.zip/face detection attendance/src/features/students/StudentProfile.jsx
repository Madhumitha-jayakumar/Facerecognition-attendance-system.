import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
    User,
    Mail,
    Phone,
    Calendar,
    GraduationCap,
    TrendingUp,
    Download,
    AlertTriangle,
    ArrowLeft,
    CheckCircle2,
    XCircle,
    ShieldCheck
} from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import useStudentStore from '../../store/studentStore';

const StudentProfile = () => {
    const navigate = useNavigate();
    const { id } = useParams();
    const { students } = useStudentStore();

    const student = useMemo(() =>
        students.find(s => s.id === id) || students[0],
        [id, students]);

    if (!student) return <div className="text-white">Loading student...</div>;

    const recentAttendance = [
        { date: '2026-02-19', course: 'General Session', status: 'Present', time: '10:05 AM' },
        { date: '2026-02-18', course: 'Dept Seminar', status: 'Present', time: '11:15 AM' },
        { date: '2026-02-17', course: 'Lab Practical', status: 'Absent', time: '-' },
    ];

    return (
        <div className="space-y-8 pb-12">
            <div className="flex items-center justify-between">
                <button
                    onClick={() => navigate('/students')}
                    className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors"
                >
                    <ArrowLeft size={20} />
                    <span>Back to Roster</span>
                </button>
                <div className="flex gap-3">
                    <button
                        onClick={(e) => {
                            const btn = e.currentTarget;
                            const original = btn.innerHTML;
                            btn.innerHTML = '<span>Exporting...</span>';
                            setTimeout(() => btn.innerHTML = original, 2000);
                        }}
                        className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-primary-600 text-white font-bold hover:bg-primary-500 transition-all active:scale-95"
                    >
                        <Download size={18} />
                        <span>Export Report</span>
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
                {/* Profile Card */}
                <div className="xl:col-span-1 space-y-8">
                    <div className="glass-card p-8 rounded-[32px] flex flex-col items-center text-center relative overflow-hidden">
                        <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-br from-primary-500/10 to-transparent -z-10"></div>

                        <div className="relative mb-6">
                            <div className="w-32 h-32 rounded-full bg-slate-800 border-4 border-slate-900 overflow-hidden shadow-2xl flex items-center justify-center">
                                <User size={64} className="text-slate-600" />
                            </div>
                            <div className="absolute -bottom-2 -right-2 w-10 h-10 rounded-2xl bg-green-500 border-4 border-slate-900 flex items-center justify-center shadow-lg">
                                <ShieldCheck size={20} className="text-white" />
                            </div>
                        </div>

                        <h2 className="text-2xl font-bold text-white mb-1">{student.name}</h2>
                        <p className="text-slate-500 text-sm font-medium mb-4 uppercase tracking-widest">{student.id}</p>

                        <div className="flex items-center gap-2 mb-8">
                            <span className="px-3 py-1 rounded-full bg-primary-500/10 text-primary-400 text-[10px] font-bold border border-primary-500/20 uppercase">
                                {student.dept}
                            </span>
                            <span className="px-3 py-1 rounded-full bg-slate-800 text-slate-400 text-[10px] font-bold border border-slate-700">
                                {student.year} YEAR
                            </span>
                        </div>

                        <div className="w-full grid grid-cols-2 gap-4 border-t border-slate-800 pt-8">
                            <div className="text-center">
                                <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Attendance</p>
                                <p className="text-xl font-bold text-white">{student.attendance}%</p>
                            </div>
                            <div className="text-center border-l border-slate-800">
                                <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Status</p>
                                <p className="text-xl font-bold text-green-400">{student.status}</p>
                            </div>
                        </div>
                    </div>

                    <div className="glass-card p-6 rounded-3xl space-y-4">
                        <h3 className="font-bold text-white text-sm">Contact Information</h3>
                        <div className="space-y-4">
                            <div className="flex items-center gap-4 text-xs text-slate-400">
                                <Mail size={14} className="text-slate-600" />
                                <span>{student.email}</span>
                            </div>
                            <div className="flex items-center gap-4 text-xs text-slate-400">
                                <GraduationCap size={14} className="text-slate-600" />
                                <span>{student.dept} Department</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Detailed Stats */}
                <div className="xl:col-span-2 space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="glass-card p-6 rounded-3xl bg-gradient-to-br from-primary-600/10 to-transparent">
                            <div className="flex justify-between items-start mb-6">
                                <div>
                                    <p className="text-[10px] text-slate-500 font-bold uppercase">Academic Progress</p>
                                    <h3 className="text-3xl font-bold text-white mt-1">Excellent</h3>
                                </div>
                                <div className="p-3 rounded-2xl bg-primary-500/20 text-primary-400">
                                    <TrendingUp size={20} />
                                </div>
                            </div>
                            <p className="text-xs text-slate-400">Above average attendance rate.</p>
                        </div>
                    </div>

                    <div className="glass-card rounded-3xl overflow-hidden">
                        <div className="p-6 border-b border-slate-800/50 flex items-center justify-between">
                            <h3 className="font-bold text-white text-sm">Recent Scans</h3>
                        </div>
                        <div className="divide-y divide-slate-800/50">
                            {recentAttendance.map((log, i) => (
                                <div key={i} className="p-5 flex items-center justify-between hover:bg-white/5 transition-all">
                                    <div className="flex items-center gap-4">
                                        <div className={`p-2 rounded-xl ${log.status === 'Present' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
                                            {log.status === 'Present' ? <CheckCircle2 size={18} /> : <XCircle size={18} />}
                                        </div>
                                        <div>
                                            <p className="text-sm font-bold text-white">{log.course}</p>
                                            <p className="text-[10px] text-slate-500">{log.date}</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-xs font-bold text-white">{log.status}</p>
                                        <p className="text-[10px] text-slate-500">{log.time}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="bg-blue-500/10 border border-blue-500/20 p-6 rounded-3xl flex gap-4">
                        <AlertTriangle className="text-blue-500 flex-shrink-0" size={20} />
                        <div>
                            <h4 className="font-bold text-white text-sm mb-1">Administrative Note</h4>
                            <p className="text-xs text-slate-400 leading-relaxed">
                                Attendance for the current semester is being monitored automatically. No discrepancies found for this student.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default StudentProfile;
