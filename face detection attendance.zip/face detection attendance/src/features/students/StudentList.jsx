import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    Search,
    UserPlus,
    Filter,
    Trash2,
    Plus,
    CheckCircle2,
    XCircle,
    ChevronRight,
    Loader2,
    AlertCircle
} from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import useStudentStore from '../../store/studentStore';

const StudentList = () => {
    const navigate = useNavigate();
    const { students, deleteStudent } = useStudentStore();
    const [searchTerm, setSearchTerm] = useState('');
    const [filterDept, setFilterDept] = useState('All');
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(null);

    const filteredStudents = students.filter(student =>
        (student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            student.id.toLowerCase().includes(searchTerm.toLowerCase())) &&
        (filterDept === 'All' || student.dept === filterDept)
    );

    const departments = ['All', 'Computer Science', 'MCA'];

    const handleDelete = (id) => {
        deleteStudent(id);
        setShowDeleteConfirm(null);
    };

    return (
        <div className="space-y-8 pb-12">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                >
                    <h1 className="text-3xl font-bold text-white mb-2">MCA Student Roster</h1>
                    <p className="text-slate-400 font-medium tracking-tight">Computer Science Department Data Management</p>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                >
                    <Link
                        to="/students/add"
                        className="flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-primary-600 text-white font-bold hover:bg-primary-500 transition-all shadow-xl shadow-primary-600/20 active:scale-95"
                    >
                        <UserPlus size={18} />
                        <span>Register Student</span>
                    </Link>
                </motion.div>
            </div>

            <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-1 relative group">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-primary-400 transition-colors" size={20} />
                    <input
                        type="text"
                        placeholder="Search student by name or roll number..."
                        className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 text-sm outline-none text-white focus:border-primary-500/50 transition-all"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>

                <div className="relative">
                    <Filter className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                    <select
                        className="bg-slate-900 border border-slate-800 rounded-2xl py-4 pl-12 pr-10 text-sm outline-none text-white focus:border-primary-500/50 appearance-none cursor-pointer min-w-[200px]"
                        value={filterDept}
                        onChange={(e) => setFilterDept(e.target.value)}
                    >
                        {departments.map(dept => <option key={dept} value={dept}>{dept}</option>)}
                    </select>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <AnimatePresence mode="popLayout">
                    {filteredStudents.map((student, index) => (
                        <motion.div
                            layout
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            transition={{ duration: 0.3, delay: index * 0.05 }}
                            key={student.id}
                            className="glass-card p-6 rounded-[32px] border border-slate-800/50 hover:border-primary-500/30 transition-all group relative overflow-hidden"
                        >
                            <div className="flex items-start justify-between mb-6">
                                <div className="w-14 h-14 rounded-2xl bg-slate-800 flex items-center justify-center border border-slate-700 shadow-inner group-hover:border-primary-500/50 transition-colors">
                                    <span className="text-xl font-bold text-slate-500 group-hover:text-primary-400">{student.name.charAt(0)}</span>
                                </div>
                                <button
                                    onClick={() => setShowDeleteConfirm(student.id)}
                                    className="p-2 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-all"
                                >
                                    <Trash2 size={18} />
                                </button>
                            </div>

                            <div className="space-y-1 mb-6">
                                <h3 className="text-lg font-bold text-white truncate">{student.name}</h3>
                                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">{student.id}</p>
                            </div>

                            <div className="grid grid-cols-2 gap-4 mb-6">
                                <div className="bg-slate-800/40 rounded-2xl p-3 border border-slate-800">
                                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Dept</p>
                                    <p className="text-xs text-white font-semibold truncate">{student.dept}</p>
                                </div>
                                <div className="bg-slate-800/40 rounded-2xl p-3 border border-slate-800">
                                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Attendance</p>
                                    <p className={`text-xs font-bold ${student.attendance < 75 ? 'text-red-400' : 'text-green-400'}`}>
                                        {student.attendance}%
                                    </p>
                                </div>
                            </div>

                            <button
                                onClick={() => navigate(`/students/${student.id}`)}
                                className="w-full py-4 rounded-2xl bg-slate-800/50 text-slate-300 text-sm font-bold hover:bg-slate-800 hover:text-white transition-all flex items-center justify-center gap-2 group/btn"
                            >
                                <span>View Profile</span>
                                <ChevronRight size={16} className="group-hover/btn:translate-x-1 transition-transform" />
                            </button>

                            {/* Delete Confirmation Overlay */}
                            <AnimatePresence>
                                {showDeleteConfirm === student.id && (
                                    <motion.div
                                        initial={{ opacity: 0 }}
                                        animate={{ opacity: 1 }}
                                        exit={{ opacity: 0 }}
                                        className="absolute inset-0 z-30 bg-slate-900/95 backdrop-blur-md rounded-[32px] p-6 flex flex-col items-center justify-center text-center px-8 border-2 border-red-500/20"
                                    >
                                        <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mb-4">
                                            <AlertCircle size={32} className="text-red-500" />
                                        </div>
                                        <h4 className="text-white font-bold mb-1">Delete Student</h4>
                                        <p className="text-xs text-slate-400 mb-6">Permanently remove from roster?</p>
                                        <div className="flex gap-3 w-full">
                                            <button
                                                onClick={() => setShowDeleteConfirm(null)}
                                                className="flex-1 py-3.5 rounded-xl bg-slate-800 text-white text-xs font-bold hover:bg-slate-700 transition-all"
                                            >
                                                Keep
                                            </button>
                                            <button
                                                onClick={() => handleDelete(student.id)}
                                                className="flex-1 py-3.5 rounded-xl bg-red-600 text-white text-xs font-bold hover:bg-red-500 shadow-lg shadow-red-600/25 active:scale-95 transition-all"
                                            >
                                                Delete
                                            </button>
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>

            {filteredStudents.length === 0 && (
                <div className="flex flex-col items-center justify-center py-32 bg-slate-900/20 rounded-[48px] border-2 border-dashed border-slate-800">
                    <Search size={48} className="text-slate-800 mb-4" />
                    <p className="text-slate-500 font-medium">No students found matching your search</p>
                </div>
            )}
        </div>
    );
};

export default StudentList;
