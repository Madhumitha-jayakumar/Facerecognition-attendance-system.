import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    User,
    IdCard,
    GraduationCap,
    Camera,
    CheckCircle2,
    ArrowRight,
    ArrowLeft,
    Loader2,
    AlertCircle,
    Scan,
    RefreshCw
} from 'lucide-react';
import * as faceapi from 'face-api.js';
import { useNavigate } from 'react-router-dom';
import useStudentStore from '../../store/studentStore';

const MODEL_URL = '/models';

const AddStudent = () => {
    const { addStudent } = useStudentStore();
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({
        name: '',
        id: '',
        dept: 'Computer Science',
        year: '2nd',
        email: '',
        faceDescriptor: null
    });
    const [isCapturing, setIsCapturing] = useState(false);
    const [samplesCaptured, setSamplesCaptured] = useState(0);
    const [isSaving, setIsSaving] = useState(false);
    const [modelsLoaded, setModelsLoaded] = useState(false);
    const [loadError, setLoadError] = useState(null);
    const videoRef = useRef(null);
    const navigate = useNavigate();

    // Store descriptors for averaging
    const descriptorsRef = useRef([]);

    useEffect(() => {
        const loadModels = async () => {
            try {
                setLoadError(null);
                await Promise.all([
                    faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
                    faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
                    faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL)
                ]);
                setModelsLoaded(true);
            } catch (err) {
                console.error("Model loading failed:", err);
                setLoadError("Failed to load AI models. Please ensure models are in /public/models.");
            }
        };
        loadModels();
    }, []);

    const handleInputChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const nextStep = () => setStep(step + 1);
    const prevStep = () => setStep(step - 1);

    const startCamera = async () => {
        // Small delay to ensure the video element is mounted if this was just triggered by a state change
        await new Promise(resolve => setTimeout(resolve, 300));

        try {
            const constraints = {
                video: {
                    facingMode: 'user',
                    width: { ideal: 1280 },
                    height: { ideal: 720 }
                }
            };
            const stream = await navigator.mediaDevices.getUserMedia(constraints);
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
                await videoRef.current.play().catch(e => console.warn("Video play failed:", e));
            }
            setIsCapturing(true);
        } catch (err) {
            console.error("Error accessing camera:", err);
            alert(`Cannot access camera: ${err.message}. Please check permissions and ensure no other app is using the camera.`);
        }
    };

    const stopCamera = () => {
        if (videoRef.current && videoRef.current.srcObject) {
            const tracks = videoRef.current.srcObject.getTracks();
            tracks.forEach(track => track.stop());
        }
        setIsCapturing(false);
    };

    // Auto-capture logic for faster registration
    useEffect(() => {
        let isCancelled = false;
        let timeoutId = null;

        const autoCapture = async () => {
            if (isCancelled || step !== 2 || !modelsLoaded || !videoRef.current || samplesCaptured >= 5 || isSaving) {
                return;
            }

            try {
                const detection = await faceapi
                    .detectSingleFace(videoRef.current, new faceapi.TinyFaceDetectorOptions())
                    .withFaceLandmarks()
                    .withFaceDescriptor();

                if (detection) {
                    descriptorsRef.current.push(Array.from(detection.descriptor));
                    setSamplesCaptured(prev => {
                        const next = prev + 1;
                        if (next === 5) {
                            const avgDescriptor = descriptorsRef.current[0].map((_, i) =>
                                descriptorsRef.current.reduce((acc, desc) => acc + desc[i], 0) / 5
                            );
                            setFormData(f => ({ ...f, faceDescriptor: avgDescriptor }));
                        }
                        return next;
                    });

                    // Small delay before next auto-capture to allow posing
                    if (!isCancelled) timeoutId = setTimeout(autoCapture, 800);
                } else {
                    // Try again quickly if no face found
                    if (!isCancelled) timeoutId = setTimeout(autoCapture, 500);
                }
            } catch (err) {
                console.error("Auto-capture error:", err);
                if (!isCancelled) timeoutId = setTimeout(autoCapture, 1000);
            }
        };

        if (step === 2 && modelsLoaded && isCapturing) {
            autoCapture();
        }

        return () => {
            isCancelled = true;
            if (timeoutId) clearTimeout(timeoutId);
        };
    }, [step, modelsLoaded, isCapturing, samplesCaptured, isSaving]);

    const captureSample = async () => {
        // Manual capture still allowed but less necessary now
        if (!modelsLoaded || !videoRef.current || samplesCaptured >= 5) return;

        try {
            const detection = await faceapi
                .detectSingleFace(videoRef.current, new faceapi.TinyFaceDetectorOptions())
                .withFaceLandmarks()
                .withFaceDescriptor();

            if (detection) {
                descriptorsRef.current.push(Array.from(detection.descriptor));
                setSamplesCaptured(prev => prev + 1);

                // If we reached 5 samples, average them for a robust baseline
                if (descriptorsRef.current.length === 5) {
                    const avgDescriptor = descriptorsRef.current[0].map((_, i) =>
                        descriptorsRef.current.reduce((acc, desc) => acc + desc[i], 0) / 5
                    );
                    setFormData(prev => ({ ...prev, faceDescriptor: avgDescriptor }));
                }
            } else {
                alert("No face detected! Please reposition and try again.");
            }
        } catch (err) {
            console.error("Capture error:", err);
            alert("Error during face scan. Please ensure good lighting.");
        }
    };

    const handleSave = () => {
        setIsSaving(true);
        // Add to global store
        addStudent(formData);

        setTimeout(() => {
            setIsSaving(false);
            stopCamera();
            navigate('/students');
        }, 1500);
    };

    useEffect(() => {
        if (step === 2 && !isCapturing) {
            startCamera();
        }
        return () => {
            if (isCapturing) stopCamera();
        };
    }, [step]);

    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="flex items-center gap-4">
                <button
                    onClick={() => step === 1 ? navigate('/students') : prevStep()}
                    className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
                >
                    <ArrowLeft size={20} />
                </button>
                <div>
                    <h1 className="text-3xl font-bold text-white">Enroll New Student</h1>
                    <p className="text-slate-400">Arts & Science College Enrollment</p>
                </div>
            </div>

            <div className="flex gap-2 mb-8">
                {[1, 2].map((i) => (
                    <div
                        key={i}
                        className={`h-2 flex-1 rounded-full transition-all duration-500 ${step >= i ? 'bg-primary-500 shadow-[0_0_10px_rgba(52,89,255,0.5)]' : 'bg-slate-800'
                            }`}
                    />
                ))}
            </div>

            <AnimatePresence mode="wait">
                {step === 1 ? (
                    <motion.div
                        key="step1"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="glass-card p-8 rounded-3xl"
                    >
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="space-y-6">
                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300 ml-1">Full Name</label>
                                    <div className="relative group">
                                        <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-primary-400" />
                                        <input
                                            type="text"
                                            name="name"
                                            value={formData.name}
                                            onChange={handleInputChange}
                                            className="w-full bg-slate-900/50 border border-slate-700/50 rounded-xl py-3.5 pl-12 pr-4 focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 outline-none transition-all text-white"
                                            placeholder="Student Name"
                                        />
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300 ml-1">Roll Number / ID</label>
                                    <div className="relative group">
                                        <IdCard size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-primary-400" />
                                        <input
                                            type="text"
                                            name="id"
                                            value={formData.id}
                                            onChange={handleInputChange}
                                            className="w-full bg-slate-900/50 border border-slate-700/50 rounded-xl py-3.5 pl-12 pr-4 focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 outline-none transition-all text-white"
                                            placeholder="AS-2024-001"
                                        />
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300 ml-1">Email (Optional)</label>
                                    <input
                                        type="email"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleInputChange}
                                        className="w-full bg-slate-900/50 border border-slate-700/50 rounded-xl py-3.5 px-4 focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 outline-none transition-all text-white"
                                        placeholder="email@college.edu"
                                    />
                                </div>
                            </div>

                            <div className="space-y-6">
                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300 ml-1">Department</label>
                                    <div className="relative">
                                        <GraduationCap size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
                                        <select
                                            name="dept"
                                            value={formData.dept}
                                            onChange={handleInputChange}
                                            className="w-full bg-slate-900/50 border border-slate-700/50 rounded-xl py-3.5 pl-12 pr-4 focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 outline-none transition-all text-white appearance-none"
                                        >
                                            <option value="Computer Science">Computer Science</option>
                                            <option value="MCA">MCA (Masters)</option>
                                        </select>
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300 ml-1">Academic Year</label>
                                    <div className="py-3.5 px-6 rounded-xl bg-primary-500/10 border border-primary-500/30 text-primary-400 font-bold text-center">
                                        2nd Year (Standard)
                                    </div>
                                    <p className="text-[10px] text-slate-500 mt-2 ml-1 uppercase font-bold tracking-tighter">Automatic enrollment for this classroom session</p>
                                </div>
                            </div>
                        </div>

                        <div className="mt-12 flex justify-end">
                            <button
                                onClick={nextStep}
                                disabled={!formData.name || !formData.id}
                                className="flex items-center gap-2 px-8 py-4 rounded-2xl bg-primary-600 text-white font-bold hover:bg-primary-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed group shadow-lg shadow-primary-600/20"
                            >
                                <span>Proceed to Face Scan</span>
                                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                            </button>
                        </div>
                    </motion.div>
                ) : (
                    <motion.div
                        key="step2"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="grid grid-cols-1 lg:grid-cols-2 gap-8"
                    >
                        <div className="glass-card p-6 rounded-3xl relative overflow-hidden flex flex-col items-center">
                            <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-2xl">
                                <video
                                    ref={videoRef}
                                    autoPlay
                                    muted
                                    playsInline
                                    className="w-full h-full object-cover scale-x-[-1]"
                                />

                                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                    <div className="w-64 h-64 border-2 border-primary-500/50 rounded-[40px] relative">
                                        <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-primary-500 rounded-tl-xl"></div>
                                        <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-primary-500 rounded-tr-xl"></div>
                                        <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-primary-500 rounded-bl-xl"></div>
                                        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-primary-500 rounded-br-xl"></div>

                                        <motion.div
                                            animate={{ top: ['0%', '100%', '0%'] }}
                                            transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
                                            className="absolute left-0 right-0 h-0.5 bg-primary-500/50 shadow-[0_0_15px_rgba(52,89,255,1)]"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="w-full mt-6 space-y-4">
                                <div className="flex justify-between items-end">
                                    <div className="space-y-1">
                                        <p className="text-white font-semibold">Face Samples</p>
                                        <p className="text-xs text-slate-500">Capture 5 poses for baseline data</p>
                                    </div>
                                    <span className="text-primary-400 font-bold text-lg">{samplesCaptured}/5</span>
                                </div>
                                <div className="flex gap-2">
                                    {[1, 2, 3, 4, 5].map((i) => (
                                        <div
                                            key={i}
                                            className={`h-2 flex-1 rounded-full transition-all duration-300 ${samplesCaptured >= i ? 'bg-primary-500 shadow-[0_0_8px_rgba(52,89,255,0.6)]' : 'bg-slate-800'
                                                }`}
                                        />
                                    ))}
                                </div>
                            </div>

                            <button
                                onClick={captureSample}
                                disabled={samplesCaptured >= 5 || !modelsLoaded}
                                className="mt-8 relative group"
                            >
                                <div className="absolute -inset-1 bg-primary-600 rounded-full blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
                                <div className="relative flex items-center justify-center w-20 h-20 bg-slate-900 rounded-full border-4 border-slate-800 group-hover:border-primary-500 transition-all active:scale-90 text-white">
                                    {!modelsLoaded ? <RefreshCw className="animate-spin" size={28} /> : <Camera size={28} />}
                                </div>
                                {!modelsLoaded && !loadError && <p className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-[10px] font-bold text-slate-500 uppercase tracking-widest whitespace-nowrap">Initializing AI...</p>}
                                {loadError && (
                                    <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1">
                                        <p className="text-[10px] font-bold text-red-500 uppercase tracking-widest whitespace-nowrap flex items-center gap-1">
                                            <AlertCircle size={10} /> Error Loading Models
                                        </p>
                                        <button
                                            onClick={() => window.location.reload()}
                                            className="text-[8px] font-black text-primary-400 uppercase tracking-tighter hover:text-white"
                                        >
                                            Retry
                                        </button>
                                    </div>
                                )}
                            </button>
                        </div>

                        <div className="flex flex-col gap-6">
                            <div className="glass-card p-6 rounded-3xl border-primary-500/20 bg-primary-500/5">
                                <div className="flex gap-4">
                                    <div className="p-3 rounded-2xl bg-primary-500/20 text-primary-400 h-fit">
                                        <Scan size={24} />
                                    </div>
                                    <div className="space-y-2">
                                        <h3 className="font-bold text-white text-sm">Scan Help</h3>
                                        <p className="text-xs text-slate-400">Please ensure the student's face is clearly visible in the frame with good lighting.</p>
                                    </div>
                                </div>
                            </div>

                            <div className="flex-1 glass-card p-6 rounded-3xl flex flex-col justify-between">
                                <div>
                                    <h3 className="font-bold text-white mb-4">Summary</h3>
                                    <div className="space-y-3">
                                        <div className="flex justify-between text-sm py-2 border-b border-slate-800/50 text-white">
                                            <span className="text-slate-500">Name</span>
                                            <span>{formData.name}</span>
                                        </div>
                                        <div className="flex justify-between text-sm py-2 border-b border-slate-800/50 text-white">
                                            <span className="text-slate-500">ID</span>
                                            <span>{formData.id}</span>
                                        </div>
                                        <div className="flex justify-between text-sm py-2 text-white">
                                            <span className="text-slate-500">Dept</span>
                                            <span>{formData.dept}</span>
                                        </div>
                                    </div>
                                </div>

                                <button
                                    onClick={handleSave}
                                    disabled={samplesCaptured < 5 || isSaving}
                                    className="w-full mt-8 py-4 rounded-2xl bg-white text-black font-bold hover:bg-slate-200 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                                >
                                    {isSaving ? <Loader2 size={20} className="animate-spin" /> : <CheckCircle2 size={20} />}
                                    <span>{isSaving ? 'Registering...' : 'Complete Registration'}</span>
                                </button>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default AddStudent;
